// App.js
import React, { useState, useEffect } from 'react';
import { SafeAreaView, Text, View, Image, StyleSheet, TouchableOpacity, ScrollView, TextInput } from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { NavigationContainer } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import productsData from './products.json'; // Import dữ liệu sản phẩm

// HomeScreen Component
function HomeScreen({ navigation }) {
  const [cart, setCart] = useState([]);

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    const storedCart = await AsyncStorage.getItem('cart');
    if (storedCart) {
      setCart(JSON.parse(storedCart));
    }
  };

  const addToCart = async (product) => {
    const updatedCart = [...cart];
    const index = updatedCart.findIndex(item => item.id === product.id);
    if (index !== -1) {
      updatedCart[index].quantity += 1; // Tăng số lượng sản phẩm
    } else {
      updatedCart.push({ ...product, quantity: 1 }); // Thêm sản phẩm mới
    }
    setCart(updatedCart);
    await AsyncStorage.setItem('cart', JSON.stringify(updatedCart)); // Cập nhật giỏ hàng
  };

  const updateQuantity = async (id, quantity) => {
    const updatedCart = cart.map(item => {
      if (item.id === id) {
        return { ...item, quantity: quantity < 1 ? 1 : quantity }; // Đảm bảo số lượng không dưới 1
      }
      return item;
    });
    setCart(updatedCart);
    await AsyncStorage.setItem('cart', JSON.stringify(updatedCart)); // Cập nhật giỏ hàng
  };

  const calculateTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0);
  };

  const clearCart = async () => {
    setCart([]);
    await AsyncStorage.removeItem('cart'); // Xóa giỏ hàng khỏi AsyncStorage
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Xin Chào 👋</Text>
            <Text style={styles.username}>Tiến Luyện Luyện</Text>
          </View>
          <Image
            source={{ uri: 'https://kenh14cdn.com/2020/7/17/brvn-15950048783381206275371.jpg' }}
            style={styles.profileImage}
          />
        </View>

        <Text style={styles.sectionTitle}>Thông tin của bạn</Text>

        <View style={styles.cardsContainer}>
          {productsData.map(product => (
            <TouchableOpacity 
              key={product.id} 
              style={styles.card} 
              onPress={() => addToCart(product)} // Thêm sản phẩm vào giỏ hàng
            >
              <Icon name="cart" size={35} color="#FF5722" />
              <Text style={styles.cardTitle}>{product.name}</Text>
              <Text style={styles.cardSubtitle}>Giá: {product.price} VNĐ</Text>
            </TouchableOpacity>
          ))}
        </View>

        <Text style={styles.totalTitle}>Tổng giá trị đơn hàng: {calculateTotal()} VNĐ</Text>
        
        {/* Giỏ hàng */}
        <View style={styles.cartContainer}>
          {cart.map(item => (
            <View key={item.id} style={styles.cartItem}>
              <Text style={styles.cartItemTitle}>{item.name}</Text>
              <Text style={styles.cartItemSubtitle}>Giá: {item.price} VNĐ</Text>
              <TextInput 
                style={styles.quantityInput} 
                keyboardType="numeric" 
                value={String(item.quantity)} 
                onChangeText={(text) => updateQuantity(item.id, Number(text))} 
              />
            </View>
          ))}
        </View>

        {/* Nút xóa giỏ hàng */}
        <TouchableOpacity onPress={clearCart} style={styles.clearButton}>
          <Text style={styles.clearButtonText}>Xóa Giỏ Hàng</Text>
        </TouchableOpacity>

        {/* Khám Phá Thêm Section */}
        <Text style={styles.exploreTitle}>Khám Phá Thêm</Text>

        {/* Horizontal Scroll for Explore Images */}
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.exploreContainer}>
          <Image
            source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTvBhCAtyR2AC5jrn-ELDWCrEgJVFAutEcgVA&s' }}
            style={styles.exploreImage}
          />
          <Image
            source={{ uri: 'https://img.lazcdn.com/g/p/b8a146b3560d16169a7ef315fafc56cd.jpg_960x960q80.jpg_.webp' }}
            style={styles.exploreImage}
          />
          <Image
            source={{ uri: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2SGWgc2m1hvCTmcq1IUdklx8xIYmWwjNPbg&s' }}
            style={styles.exploreImage}
          />
          <Image
            source={{ uri: 'https://img.lazcdn.com/g/p/fd202569b41f03fce006b185cd793877.jpg_960x960q80.jpg_.webp' }}
            style={styles.exploreImage}
          />
        </ScrollView>
      </ScrollView>
    </SafeAreaView>
  );
}

// ScanScreen Component
function ScanScreen() {
  return (
    <View style={styles.center}>
      <Text>Quét Mã</Text>
    </View>
  );
}

// Dummy Components for Other Tabs
function NotificationScreen() {
  return (
    <View style={styles.center}>
      <Text>Thông Báo</Text>
    </View>
  );
}

function TimeScreen() {
  return (
    <View style={styles.center}>
      <Text>Thời Gian</Text>
    </View>
  );
}

function CartScreen() {
  return (
    <View style={styles.center}>
      <Text>Giỏ Hàng</Text>
    </View>
  );
}

// BottomTabNavigator
const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size, focused }) => {
            let iconName;

            if (route.name === 'Home') {
              iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === 'Notifications') {
              iconName = focused ? 'notifications' : 'notifications-outline';
            } else if (route.name === 'Scan') {
              iconName = focused ? 'scan' : 'scan-outline';
            } else if (route.name === 'Time') {
              iconName = focused ? 'time' : 'time-outline';
            } else if (route.name === 'Cart') {
              iconName = focused ? 'cart' : 'cart-outline';
            }

            // Tăng kích thước icon
            return <Icon name={iconName} size={focused ? 40 : 35} color={color} />;
          },
          tabBarActiveTintColor: '#FF5722', // Màu khi tab được chọn
          tabBarInactiveTintColor: '#999', // Màu khi tab không được chọn
          tabBarStyle: {
            paddingBottom: 10, // Giảm khoảng cách dưới
            height: 70, // Tăng chiều cao tab
            backgroundColor: '#fff',
            shadowColor: '#000',
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: 0.25,
            shadowRadius: 3.84,
            elevation: 5, // Đổ bóng thanh tab
          },
          tabBarLabelStyle: {
            fontSize: 12,
            fontWeight: 'bold', // Làm chữ đậm hơn
            paddingBottom: 5, // Tạo khoảng cách giữa text và icon
          },
          headerShown: false,
        })}
      >
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Notifications" component={NotificationScreen} />
        
        {/* Custom Scan button */}
        <Tab.Screen
          name="Scan"
          component={ScanScreen}
          options={{
            tabBarButton: (props) => (
              <TouchableOpacity
                {...props}
                style={styles.scanButton}
              >
                <Icon name="scan" size={45} color="#FF5722" />
              </TouchableOpacity>
            ),
          }}
        />
        
        <Tab.Screen name="Time" component={TimeScreen} />
        <Tab.Screen name="Cart" component={CartScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}

// Styles
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#fff',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  greeting: {
    fontSize: 24,
    fontWeight: 'bold',
  },
  username: {
    fontSize: 18,
    color: '#666',
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 25,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  cardsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  card: {
    width: '48%',
    padding: 16,
    backgroundColor: '#f9f9f9',
    borderRadius: 8,
    marginBottom: 10,
    alignItems: 'center',
    elevation: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cardSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  totalTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginVertical: 20,
  },
  cartContainer: {
    marginTop: 20,
    padding: 10,
    backgroundColor: '#f2f2f2',
    borderRadius: 8,
  },
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  cartItemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
  },
  cartItemSubtitle: {
    fontSize: 16,
    color: '#666',
  },
  quantityInput: {
    width: 60,
    borderWidth: 1,
    borderColor: '#ddd',
    borderRadius: 5,
    padding: 5,
    textAlign: 'center',
  },
  clearButton: {
    backgroundColor: '#FF5722',
    padding: 10,
    borderRadius: 5,
    marginTop: 20,
    alignItems: 'center',
  },
  clearButtonText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  exploreTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginVertical: 10,
  },
  exploreContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  exploreImage: {
    width: 120,
    height: 120,
    marginRight: 10,
    borderRadius: 8,
  },
  center: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scanButton: {
    top: -30,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    borderRadius: 30,
    elevation: 5, // Tạo bóng cho nút
    height: 60,
    width: 60,
  },
});
